Name: Laurentiu Pavel
email: lpavel@wpi.edu

This project cotains only one executable to run the 3 parts of the project.

In order to build it, run: make

Part 1 - Command execution
In order to run doit such that it responds to the requirements of this part, simply run ./doit "your instruciton here". This will run the command and show statistics of the system resources asked in the assignment. The implementation has been made such that when there are arguments given to the main command, it calls a function that executes the command by forking and using execvp on the child process.
Among the commands I tested and work are:
ls, ls -l, grep -i s doit_processes.cpp, pwd, more doit.cpp

In case a command is not found by the shell, it will simply state that the command was not found.

Part 2 - Basic Command Shell
This part expands the part 1 by creating a shell. In order to run the shell, just run ./doit
It will welcome you to the shell where you can run commands like the ones at part 1. For convenience, test_shell.shell file can be input to the executable. You can run ./doit < test_shell which will start the shell and run the processes contained by test_shell. The implementation was made such that when no inputs are given to main, it will call a function that starts the shell. It is basically an infinite loop that waits for an input from stdin and then handles it. The commands exit and cd have a special treatment - they do not call fork since they are processes handled by the parent. For the other ones, they are forked and executed followed by printing the system resources from the part 1.

Part 3 - Background Tasks
This part handles the background tasks. When a command ends with a '&', it will be run in the background and it will be shown as completed along with its system data, when it is done (but after another command was given from stdin). Exit waits for all the background processes to be done before it exits the shell. It runs on the same code Part 2 runs on, so it is also started just by ./doit . There is a test_shell_background.shell that tests the behavior of the background processes. In can be run in the same way ./doit < test_shell_background.shell. Regarding the implementation, the only special data structure used here is a c++ vector that keeps track of background processes. Whenever a new process is added, it will be pushed at the back of the vector. Whenever one will be finished, it will be erased from the vector
